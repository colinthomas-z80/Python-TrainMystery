
import sys

from time import sleep

kitchen = open("kitchen.txt","r")
conductorsRoom = open("conductorsRoom.txt","r")
leelasRoom = open("leelasRoom.txt","r")
rickDeckardsRoom = open("rickDeckardsRoom.txt","r")

foxMuldersRoom = open("foxMuldersRoom.txt","r")

bar = open("bar.txt","r")
bathroom = open("bathroom.txt","r")
paulCezannesRoom = open("paulCezannesRoom.txt","r")
luggage = open("luggage.txt")
coalTender = open("coalTender.txt","r")

def train():
    print('''

   __________  _________  __________  __________  __________   ____      _
  { 0 0 0 0  }{ 0 0 0 0 }{ 0 0 0 0  }{ 0 0 0 0  }{         }{  O D_____I I_
  { __1_______{____2__   { ____3____{____4____ }{____5____ }{______________ I-
   O O    O O  O O   O O  O O    O O  O O    O O  O O   O O    O  O  OOOO  OO \\
______________________________________________________________________________
------------------------------------------------------------------------------
   ''')


car1 = " "
car2 = " "
car3 = " "
car4 = " "
car5 = " "

train()
          
    
intro = open("intro.txt","r")
def typeAFile(file):
    for i in file.read():
        sleep(0.02)
        sys.stdout.write(i)
        sys.stdout.flush


class Character:
    def __init__(self,name,item):
        self.name = name
        self.item = item

locaList = []
class Location:
    def __init__(self,name,car,file):
        self.name = name
        self.car = car
        self.file = file
        locaList.append(self.car)

car1 = '''
1. My Room
2. Kitchen
'''

car2 = '''
1. Conductor's Room
2. Leela's Room
3. Rick Deckard's Room
4. Fox Mulder's Room
'''

car3 = '''
1. Bar
2. Bathroom
3. Paul Cezanne's Room
'''

car4 = '''
1. Luggage
2. Coal Tender
'''
        



platform = Location("Platform","0",open("intro.txt","r"))
typeAFile(platform.file)
name = str(input())
character = Character(name,"pistol")
location = 1

myRoom = open("room.txt","r")
                                   



def running():
    i = 0
    while i != "5":
        train()
        print("Location: Car " + str(location))
        i = input('''
1. Investigate Location
2. Talk to characters
3. Move Location
4. Access your items in your room [must be in room]
5. Quit
''')

        if i == "1":
            print("You are in car " + str(location) + ". " + "Which room do you want to investigate?")
            if location == 1:
                print(car1)
                subgum = input(" ")
                if subgum == "1":
                    typeAFile(myRoom)
                elif subgum == "2":
                    typeAFile(kitchen)
                else:
                    print("Not a location, try again")
                    i = "1"
            elif location == 2:
                print(car2)
                subgum = input(" ")
                if subgum == "1":
                    typeAFile(conductorsRoom)
                elif subgum == "2":
                    typeAFile(leelasRoom)
                elif subgum == "3":
                    typeAFile(rickDeckardsRoom)
                elif subgum == "4":
                    typeAFile(foxMuldersRoom)
                else:
                    print("Not a location, try again")
                    i = "1"
            elif location == 3:
                print(car3)
            elif location == 4:
                print(car4)
                subgum = input(" ")
                if subgum == "1":
                    typeAFile(luggage)
            elif location == 5:
                print(car5)
                
            

            
            
                
   


        
        




running()






























