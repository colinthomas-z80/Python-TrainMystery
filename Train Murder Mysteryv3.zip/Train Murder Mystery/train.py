

import sys

from time import sleep

kitchen = open("kitchen.txt","r")
conductorsRoom = open("conductorsRoom.txt","r")
leelasRoom = open("leelasRoom.txt","r")
rickDeckardsRoom = open("rickDeckardsRoom.txt","r")

foxMuldersRoom = open("foxMuldersRoom.txt","r")

bar = open("bar.txt","r")
bathroom = open("bathroom.txt","r")
paulCezannesRoom = open("paulCezannesRoom.txt","r")
luggage = open("luggage.txt")
coalTender = open("coalTender.txt","r")
deckard = open("deckard.txt","r")
leela= open("leela.txt","r")
paul = open("paul.txt","r")
conductor = open("conductor.txt","r")
car1 = '''
1. My Room
2. Kitchen
'''

car2 = '''
1. Conductor's Room
2. Leela's Room
3. Rick Deckard's Room
4. Fox Mulder's Room
'''

car3 = '''
1. Bar
2. Bathroom
3. Paul Cezanne's Room
'''

car4 = '''
1. Luggage
2. Coal Tender
'''
def train():
    print('''


                Conductor  Bar         
    My Room     Leela      Bathroom   Coal Tender  
    Kitchen     Rick       Cezanne    Luggage
   __________  _Mulder___  __________  __________  __________   ____      _
  { 0 0 0 0  }{ 0 0 0 0 }{ 0 0 0 0  }{ 0 0 0 0  }{         }{  O D_____I I_
  { __1_______{____2__   { ____3____{____4____ }{________ }{______________ I-
   O O    O O  O O   O O  O O    O O  O O    O O  O O   O O    O  O  OOOO  OO \\
______________________________________________________________________________
------------------------------------------------------------------------------
   ''')


car1 = " "
car2 = " "
car3 = " "
car4 = " "
car5 = " "

train()
          
    
intro = open("intro.txt","r")
def typeAFile(file):
    
    for i in file.read():
        sleep(0.02)
        sys.stdout.write(i)
    sys.stdout.flush()
    file.seek(0,0)
    


class Character:
    def __init__(self,name,item):
        self.name = name
        self.item = item

locaList = []
class Location:
    def __init__(self,name,car,file):
        self.name = name
        self.car = car
        self.file = file
        locaList.append(self.car)

car1 = '''
1. My Room
2. Kitchen
'''

car2 = '''
1. Conductor's Room
2. Leela's Room
3. Rick Deckard's Room
4. Fox Mulder's Room
'''

car3 = '''
1. Bar
2. Bathroom
3. Paul Cezanne's Room
'''

car4 = '''
1. Luggage
2. Coal Tender
'''
        



platform = Location("Platform","0",open("intro.txt","r"))
typeAFile(platform.file)
name = str(input())
character = Character(name,"pistol")
location = 1

myRoom = open("room.txt","r")
                                   



def running():
    location = 1
    i = 0
    inventory = ["pistol"]
    while i != "6":
        train()
        print("Location: Car " + str(location))
        i = input('''
1. Investigate Location
2. Talk to characters
3. Move Location
4. View your inventory
5. Accuse a suspect
6. Quit
''')
        if i == "4":
            print(inventory)

        if i == "1":
            print("You are in car " + str(location) + ". " + "Which room do you want to investigate?")
            if location == 1:
                print(car1)
                subgum = input(" ")
                if subgum == "1":
                    typeAFile(myRoom)
                    for i in inventory:
                        if i == "Note":
                            obj = False
                        else:
                            obj = True
                if obj == True:
                    inventory.append("Note")
                elif subgum == "2":
                    typeAFile(kitchen)
                else:
                    print("Not a location, try again")
                    i = "1"
            elif location == 2:
                print(car2)
                subgum = input(" ")
                if subgum == "1":
                    typeAFile(conductorsRoom)
                elif subgum == "2":
                    typeAFile(leelasRoom)
                elif subgum == "3":
                    typeAFile(rickDeckardsRoom)
                elif subgum == "4":
                    typeAFile(foxMuldersRoom)
                else:
                    print("Not a location, try again")
                    i = "1"
            elif location == 3:
                print(car3)
                subgum = input(" ")
                if subgum == "1":
                    typeAFile(bar)
                elif subgum == "2":
                    typeAFile(bathroom)
                elif subgum == "3":
                    typeAFile(paulCezannesRoom)
                else:
                    print("Not a location, try again")
                    i = "1"
            elif location == 4:
                print(car4)
                subgum = input(" ")
                if subgum == "1":
                    typeAFile(luggage)
                    for i in inventory:
                        if i == "Photos":
                            obj = False
                        else:
                            obj = True
                    if obj == True:
                        inventory.append("Photos")
                elif subgum == "2":
                    typeAFile(coalTender)
                    for i in inventory:
                        if i == "Dagger":
                            obj = False
                        else:
                            obj = True
                    if obj == True:
                        inventory.append("Dagger")
          
                else:
                    print("Not a location, try again")
                    i = "1"



        if i == "3":
            destination = int(input("Where would you like to move? "))
            if destination >= 1 and destination <= 5:
                location = destination
            else:
                print("Not a location")

        if i == "2":
            
            subject = input('''Who would you like to speak with?
1. Leela
2. Paul Cezanne
3. Conductor
4. Rick Deckard\n
''')
            if subject == "1":
                typeAFile(leela)
                for i in inventory:
                    if i == "Letter":
                        obj = False
                    else:
                        obj = True
                if obj == True:
                    inventory.append("Letter")
            if subject == "2":
                typeAFile(paul)
            if subject == "3":
                typeAFile(conductor)
            if subject == "4":
                typeAFile(deckard)


        if i == "5":
            accuse = input('''Who do you accuse as the killer of Fox Mulder?
1. Leela
2. Rick Deckard
3. Paul Cezanne
4. Conductor
''')

            if accuse == "1":
                if secret == False:
                    typeAFile(leelaInnocent)
                else:
                    typeAFile(leelaGuilty)
                    inventory.append("Amulet of Kings")
                    sys.exit()
            elif accuse == "2":
                typeAFile(rickInnocent)
            elif accuse == "3":
                typeAFile(paulInnocent)
            elif accuse == "4":
                typeAFile(conductorInnocent)
                inventory.append("Daedric Artifacts")
                secret = True

secret = False               
            
leelaInnocent = open("leelaInnocent.txt","r")
leelaGuilty = open("leelaGuilty.txt","r")
rickInnocent = open("rickInnocent.txt","r")
paulInnocent = open("paulInnocent.txt","r")
conductorInnocent = open("conductorInnocent.txt","r")

            
                
   


        
        




running()






























